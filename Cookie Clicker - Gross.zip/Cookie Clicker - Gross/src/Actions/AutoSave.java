
package Actions;

import java.util.Timer;
import java.util.TimerTask;

public class AutoSave {
    
    Timer count;
    
    public AutoSave() {
        count = new Timer();
        count.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                
                if(!Main.start){
                Data.safeData();
                }
                
            }
        }, 0, 1); //2. Zahl = Alle wieviele Millisekunden der Timer getriggert wird
        
        
    }
}