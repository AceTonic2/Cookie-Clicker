
package Actions;

import Actions.Main;
import Actions.Audio;
import static GUI.Gui.jsMusic;
import static GUI.Gui.jsSound;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class SliderListener implements ChangeListener {
    
    int valueSound, valueMusic;

    @Override
    public void stateChanged(ChangeEvent e) {
        this.valueSound = jsSound.getValue();
        this.valueMusic = jsMusic.getValue();
        System.out.println(valueSound);
        Main.volumeSound = valueSound;
        System.out.println(valueMusic);
        Main.volumeMusic = valueMusic;
        
    }
    
    
    
}
