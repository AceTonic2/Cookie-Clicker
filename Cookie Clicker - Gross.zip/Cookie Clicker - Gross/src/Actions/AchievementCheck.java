
package Actions;

import GUI.Achievement;
import GUI.AchievementSlider;
import GUI.Gui;
import java.util.Timer;
import java.util.TimerTask;

public class AchievementCheck {
    
    Timer time;
    
    public AchievementCheck() {
        
        time = new Timer();
        time.schedule(new TimerTask() {
            
            @Override
            public void run() {
                
                //Achievement 1
                if(!Gui.achievement[0].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1.0){
                        unlock(Gui.achievement[0], Gui.achievementSlider[0]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 2
                if(!Gui.achievement[1].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000.0){
                        unlock(Gui.achievement[1], Gui.achievementSlider[1]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 3
                if(!Gui.achievement[2].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000.0){
                        unlock(Gui.achievement[2], Gui.achievementSlider[2]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 4
                if(!Gui.achievement[3].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000.0){
                        unlock(Gui.achievement[3], Gui.achievementSlider[3]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 5
                if(!Gui.achievement[4].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000.0){
                        unlock(Gui.achievement[4], Gui.achievementSlider[4]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 6
                if(!Gui.achievement[5].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000.0){
                        unlock(Gui.achievement[5], Gui.achievementSlider[5]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 7
                if(!Gui.achievement[6].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000.0){
                        unlock(Gui.achievement[6], Gui.achievementSlider[6]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 8
                if(!Gui.achievement[7].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000.0){
                        unlock(Gui.achievement[7], Gui.achievementSlider[7]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 9
                if(!Gui.achievement[8].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000.0){
                        unlock(Gui.achievement[8], Gui.achievementSlider[8]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 10
                if(!Gui.achievement[9].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000.0){
                        unlock(Gui.achievement[9], Gui.achievementSlider[9]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 11
                if(!Gui.achievement[10].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000.0){
                        unlock(Gui.achievement[10], Gui.achievementSlider[10]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 12
                if(!Gui.achievement[11].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000.0){
                        unlock(Gui.achievement[11], Gui.achievementSlider[11]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 13
                if(!Gui.achievement[12].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000.0){
                        unlock(Gui.achievement[12], Gui.achievementSlider[12]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 14
                if(!Gui.achievement[13].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000.0){
                        unlock(Gui.achievement[13], Gui.achievementSlider[13]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 15
                if(!Gui.achievement[14].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000.0){
                        unlock(Gui.achievement[14], Gui.achievementSlider[14]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 16
                if(!Gui.achievement[15].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000.0){
                        unlock(Gui.achievement[15], Gui.achievementSlider[15]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 17
                if(!Gui.achievement[16].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000.0){
                        unlock(Gui.achievement[16], Gui.achievementSlider[16]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 18
                if(!Gui.achievement[17].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000000.0){
                        unlock(Gui.achievement[17], Gui.achievementSlider[17]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 19
                if(!Gui.achievement[18].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000000.0){
                        unlock(Gui.achievement[18], Gui.achievementSlider[18]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 20
                if(!Gui.achievement[18].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000000000.0){
                        unlock(Gui.achievement[19], Gui.achievementSlider[19]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 21
                if(!Gui.achievement[20].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000000000.0){
                        unlock(Gui.achievement[20], Gui.achievementSlider[20]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 22
                if(!Gui.achievement[21].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000000000000.0){
                        unlock(Gui.achievement[21], Gui.achievementSlider[21]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 23
                if(!Gui.achievement[22].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000000000000.0){
                        unlock(Gui.achievement[22], Gui.achievementSlider[22]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 24
                if(!Gui.achievement[23].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[23], Gui.achievementSlider[23]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 25
                if(!Gui.achievement[24].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[24], Gui.achievementSlider[24]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 26
                if(!Gui.achievement[25].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[25], Gui.achievementSlider[25]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 27
                if(!Gui.achievement[26].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[26], Gui.achievementSlider[26]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 28
                if(!Gui.achievement[27].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[27], Gui.achievementSlider[27]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 29
                if(!Gui.achievement[28].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[28], Gui.achievementSlider[28]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 30
                if(!Gui.achievement[29].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[29], Gui.achievementSlider[29]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 31
                if(!Gui.achievement[30].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[30], Gui.achievementSlider[30]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 32
                if(!Gui.achievement[31].isUnlocked()){
                    if(Main.StatsCookiesTotal>=1000000000000000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[31], Gui.achievementSlider[31]);
                        Main.StatsAchievementCount += 1;
                    }
                }
                
                //Achievement 33
                if(!Gui.achievement[32].isUnlocked()){
                    if(Main.StatsCookiesTotal>=100000000000000000000000000000000000000000000000000.0){
                        unlock(Gui.achievement[32], Gui.achievementSlider[32]);
                        Main.StatsAchievementCount += 1;
                    }
                }  
                
                
            }
        }, 1000, 1000);
    }
    
    public static void unlock(Achievement achievement, AchievementSlider slider){
        
        if(AchievementSlider.active == false){ //damit nicht 2 auf einmal aktiv sind
        achievement.setUnlocked(true);
        slider.setVisible(true);
        AchievementSlider.slideIn(slider);
        }
    }
    
}
