
package Actions;

import java.io.File;
import java.util.Random;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;

public class Audio {
    
    static boolean fadeIn = true;
   
    public static synchronized void Music(String track) {
    
        final String trackname = track;
        Random zufall = new Random();
        int percentage = Main.volumeMusic;
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                
                try{
                        Clip clip = AudioSystem.getClip();
                        AudioInputStream inputstream = AudioSystem.getAudioInputStream(new File(trackname));
                        clip.open(inputstream);
                        FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                        clip.setFramePosition(zufall.nextInt(173579337)); //man könnte sich die mühe machen die framePositionen von den Start der Lieder zu suchen, oder mehrere Lieder
                        float min = -45.0f;
                        float volume = percentage * (-min/100.0f) + min;
                        
                        if(fadeIn){
                        for (int i = 0; i<=percentage ; i++){
                        volume = i * (-min/100.0f) + min;
                        gainControl.setValue(volume);
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                        Thread.sleep(100);
                        fadeIn=false;
                        }
                        }
                        
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                        
                while(true){
                    volume = Main.volumeMusic * (-min/100.0f) + min;
                    gainControl.setValue(volume);
                    Thread.sleep(1000);
                }
                        
                        }catch(Exception e){
                        e.printStackTrace();
                    }
               
                
                /*while(true){
                    
                    try{
                        
                        Clip clip = AudioSystem.getClip();
                        AudioInputStream inputstream = AudioSystem.getAudioInputStream(new File(trackname));
                        clip.open(inputstream);
                        FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                        clip.setFramePosition(zufall.nextInt(173579337)); //man könnte sich die mühe machen die framePositionen von den Start der Lieder zu suchen, oder mehrere Lieder
                        float min = -45.0f;
                        float volume = percentage * (-min/100.0f) + min;
                        System.out.println(volume);
                        
                        if(fadeIn){
                        for (int i = 0; i<=percentage ; i++){
                        volume = i * (-min/100.0f) + min;
                        gainControl.setValue(volume);
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                        Thread.sleep(200);
                        System.out.println(volume);
                        fadeIn=false;
                        }
                        }
                        
                        System.out.println(volume);
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                        
                        //Thread.sleep(clip.getMicrosecondLength()/1000);
                        
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }*/
            }
        }).start();
        
}
    
    
    public static synchronized void Audio(String track, int percentage) {
        
        final String trackname = track;
    
    try{
                        
                        Clip clip = AudioSystem.getClip();
                        AudioInputStream inputstream = AudioSystem.getAudioInputStream(new File(trackname));
                        clip.open(inputstream);
                        FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                        float min = -25.0f;
                        float volume = percentage * (-min/100.0f) + min;
                        gainControl.setValue(volume);
                        clip.start();
                        
                        
                        
                        
                    }catch(Exception e){
                        e.printStackTrace();
                    }
    }
}
