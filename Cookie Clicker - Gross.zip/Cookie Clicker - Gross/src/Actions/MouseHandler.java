
package Actions;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import GUI.Button;
import GUI.Gui;
import GUI.Upgrade;
import Actions.Main;
import Draw.Draw_Start;

public class MouseHandler implements MouseListener, MouseMotionListener, MouseWheelListener {

    Gui gui = new Gui();
    MouseCollision mc = new MouseCollision();
    
    int cookieclicksound = (int) (Math.random()*7)+1;
    
    @Override
    public void mouseClicked(MouseEvent me) {
        
    }

    @Override
    public void mousePressed(MouseEvent me) {
        
        if(!Main.start){
        //Upgrades Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonUpgrades)){
          Button.setActive(Gui.buttonUpgrades);
          Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
        }
        
        //Achivement Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonAchievements)){
          Button.setActive(Gui.buttonAchievements);
          Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
        }
        
        //Options Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonOptions)){
          Button.setActive(Gui.buttonOptions);
          Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
        }
        //Highscore Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscore)){
          Button.setActive(Gui.buttonHighscore);
          Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
        }
        
        //Cookie Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonCookie)){
          Gui.buttonCookie.setActive(true);
          Main.cookies += Main.cpc;
          Main.StatsClickCount += 1;
          Main.StatsCookiesTotal += Main.cpc;
          
          Audio.Audio("data/audio/clickb"+cookieclicksound+".wav", Main.volumeSound);

        
        }
        
        //Upgrade Buttons
        for(int i = 0; i<Gui.upgrade.length; i++){
            if(mc.inside(me.getX(), me.getY(), Gui.buyUpgradeButton[i])){
                if(Gui.buttonUpgrades.isActive()){
                    if(Main.cookies > Gui.upgrade[i].cost){
                        int random = (int)(Math.random()*4)+1;
                        Audio.Audio("data/audio/buy"+random+".wav", Main.volumeSound);
                        Main.cookies -= Gui.upgrade[i].cost;
                        int anzahl = Gui.upgrade[i].getAnzahl();
                        Gui.upgrade[i].setAnzahl(anzahl +=1);
                        double cost = Gui.upgrade[i].getCost();
                        Gui.upgrade[i].setCost(cost/100*115);
                        Upgrade.cpsUpgrade(i);
                    }
                } 
            }
        }
        
        //Upgrade Cookie Clicker
        if(mc.inside(me.getX(), me.getY(), Gui.buttonCookieUpgrade)){
            if(Main.cookies > Main.CookieUpgradeCost){
                int random = (int)(Math.random()*4)+1;
                Audio.Audio("data/audio/buy"+random+".wav", Main.volumeSound);
                Main.cookies -= Main.CookieUpgradeCost;
                
                Main.CookieUpgradeCost *= 2;
                Main.cpc += Main.cpc/2;
            }
        }
        
        //Cookies Stats Button
        if(Gui.buttonHighscore.isActive()){
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscoreCookies)){
           Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
           Button.setActive(Gui.buttonHighscoreCookies);
           Button.setActive(Gui.buttonHighscore);
           Gui.buttonHighscoreClicks.setActive(false);
           Gui.buttonHighscoreCpc.setActive(false);
           Gui.buttonHighscoreCps.setActive(false);
            }
        }
        
        //Clicks Stats Button
        if(Gui.buttonHighscore.isActive()){
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscoreClicks)){
           Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
           Button.setActive(Gui.buttonHighscoreClicks);
           Button.setActive(Gui.buttonHighscore);
           Gui.buttonHighscoreCookies.setActive(false);
           Gui.buttonHighscoreCpc.setActive(false);
           Gui.buttonHighscoreCps.setActive(false);
            }
        }
        
        //Cpc Stats Button
        if(Gui.buttonHighscore.isActive()){
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscoreCpc)){
           Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
           Button.setActive(Gui.buttonHighscoreCpc);
           Button.setActive(Gui.buttonHighscore);
           Gui.buttonHighscoreCookies.setActive(false);
           Gui.buttonHighscoreClicks.setActive(false);
           Gui.buttonHighscoreCps.setActive(false);
            }
        }
        
        //Cps Stats Button
        if(Gui.buttonHighscore.isActive()){
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscoreCps)){
           Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
           Button.setActive(Gui.buttonHighscoreCps);
           Button.setActive(Gui.buttonHighscore);
           Gui.buttonHighscoreCookies.setActive(false);
           Gui.buttonHighscoreClicks.setActive(false);
           Gui.buttonHighscoreCpc.setActive(false);
            }
        }
    }
        
        if(Main.start){
            //Submit Button
            if(mc.inside(me.getX(), me.getY(), Gui.buttonSubmit)){
            Audio.Audio("data/audio/clickOn.wav", Main.volumeSound);
            Draw_Start.submitPressed = true;
        }
            
        }
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
        if(!Main.start){
        if(Gui.buttonCookie.isActive()){
          Gui.buttonCookie.setActive(false);
          cookieclicksound+=(int)(Math.random()*4)+1;
          if(cookieclicksound>7)
              cookieclicksound-=7;
          Audio.Audio("data/audio/clickb"+cookieclicksound+".wav", Main.volumeSound);
        }
    }
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }

    @Override
    public void mouseDragged(MouseEvent me) {
        
    }

    @Override
    public void mouseMoved(MouseEvent me) {
        
        if(!Main.start){
        //Upgrades Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonUpgrades)){
           Gui.buttonUpgrades.setHover(true);
        }else{
            Gui.buttonUpgrades.setHover(false);
        }
        
        //Achievements Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonAchievements)){
           Gui.buttonAchievements.setHover(true);
        }else{
            Gui.buttonAchievements.setHover(false);
        }
        
        //Options Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonOptions)){
           Gui.buttonOptions.setHover(true);
        }else{
            Gui.buttonOptions.setHover(false);
        }
        
        //Options Button
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscore)){
           Gui.buttonHighscore.setHover(true);
        }else{
            Gui.buttonHighscore.setHover(false);
        }
        
        //buyUpgrades Button
        for(int i = 0; i<Gui.buyUpgradeButton.length; i++){
            if(mc.inside(me.getX(), me.getY(), Gui.buyUpgradeButton[i])){
           Gui.buyUpgradeButton[i].setHover(true);
        }else{
            Gui.buyUpgradeButton[i].setHover(false);
        }
            
        }
        
        //Cookie Clicker Upgrade
        if(mc.inside(me.getX(), me.getY(), Gui.buttonCookieUpgrade)){
           Gui.buttonCookieUpgrade.setHover(true);
        }else{
            Gui.buttonCookieUpgrade.setHover(false);
        }
        
        //Cookies Stats Button
        if(Gui.buttonHighscore.isActive()){
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscoreCookies)){
           Gui.buttonHighscoreCookies.setHover(true);
        }else{
            Gui.buttonHighscoreCookies.setHover(false);
        }
        }
        
        //Clicks Stats Button
        if(Gui.buttonHighscore.isActive()){
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscoreClicks)){
           Gui.buttonHighscoreClicks.setHover(true);
        }else{
            Gui.buttonHighscoreClicks.setHover(false);
        }
        }
        
        //Cpc Stats Button
        if(Gui.buttonHighscore.isActive()){
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscoreCpc)){
           Gui.buttonHighscoreCpc.setHover(true);
        }else{
            Gui.buttonHighscoreCpc.setHover(false);
        }
        }
        
        //Cps Stats Button
        if(Gui.buttonHighscore.isActive()){
        if(mc.inside(me.getX(), me.getY(), Gui.buttonHighscoreCps)){
           Gui.buttonHighscoreCps.setHover(true);
        }else{
            Gui.buttonHighscoreCps.setHover(false);
        }
        }
        
        ////////////////////
        ////Achievements////
        ////////////////////
        
        for(int i = 0; i<Main.achievementAnzahl; i++){
            if(mc.inside(me.getX(), me.getY(), Gui.achievement[i])){
                
                Gui.achievement[i].setHover(true);
            }else{
                Gui.achievement[i].setHover(false);
            }
            
                
                }
        } 
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent mwe) {
        
        if(Gui.buttonUpgrades.isActive()){
            if(mwe.getX() > gui.width/3 && mwe.getX() < gui.width/3*2){
                
                //Runterscrollen -> Upgrades nach oben
                if(mwe.getWheelRotation() == 1){
                    Gui.actualHeight -= 20;
                    
                    if(Gui.actualHeight >= -(Gui.maxHeight - 900)){
                        for(int i = 0; i < Gui.upgrade.length; i++){
                            int y1 = Gui.upgrade[i].getY() - 20;
                            int y2 = Gui.buyUpgradeButton[i].getY() - 20;
                            
                            Gui.upgrade[i].setY(y1);
                            Gui.buyUpgradeButton[i].setY(y2);
                            
                        }
                    }else{
                        Gui.actualHeight = -(Gui.maxHeight - 900);
                    }
                }
                
                
                //Hochscrollen -> Upgrades nach unten
                if(mwe.getWheelRotation() == -1){
                    Gui.actualHeight += 20;
                    
                    if(Gui.actualHeight <= 0){
                        for(int i = 0; i < Gui.upgrade.length; i++){
                            int y1 = Gui.upgrade[i].getY() + 20;
                            int y2 = Gui.buyUpgradeButton[i].getY() + 20;
                            
                            Gui.upgrade[i].setY(y1);
                            Gui.buyUpgradeButton[i].setY(y2);
                        }
                    }else{
                        Gui.actualHeight = 0;
                    }
                } 
            }
         }
        
        
    }
    
}
