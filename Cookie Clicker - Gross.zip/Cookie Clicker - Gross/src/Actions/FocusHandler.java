
package Actions;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import GUI.Gui;

public class FocusHandler implements FocusListener {

    @Override
    public void focusGained(FocusEvent fe) {
        Gui.jt.setText("");
    }

    @Override
    public void focusLost(FocusEvent fe) {
        Gui.jt.setText("Name");
    }
    
}
