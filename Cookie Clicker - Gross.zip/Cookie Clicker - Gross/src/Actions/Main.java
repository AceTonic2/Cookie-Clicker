
package Actions;

import GUI.Gui;

public class Main {

    public static double cookies = 0; // max 1Milliarde (Idee: Tausender, Millioner etc einzeln speichern)
    public static double cps = 0; // cookies per second
    public static double cpc = 1; //cookies per click
    public static int upgradeAnzahl = 5;
    public static int achievementAnzahl = 66;
    public static double CookieUpgradeCost = 10;
    public static String spielername;
    public static boolean start = true;
    
    public static int volumeSound = 100;
    public static int volumeMusic = 25;
    
    public static int StatsClickCount = 0;
    public static int StatsAchievementCount = 0;
    public static double StatsCookiesTotal = 0;
    
    public static void main(String[] args) {

    Gui g = new Gui();
    g.createGui();
    new CookieCounter();
    new AutoSave();
    new AchievementCheck();
    
    }
    
}
 