
package Actions;

import GUI.Gui;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;

public class Data {
    
    File folder = new File("saves");
    File file = new File("saves/"+Main.spielername+"save.txt");
    StringBuilder sb = new StringBuilder();
    
    
    public static void safeData(){
        
        Data data = new Data();
        
        //Ordner erstellen
        if(!data.folder.exists()){
            data.folder.mkdirs();
        }
        
        
        if(Main.spielername!=null){
            
        //Speichern
        data.sb.append(Main.spielername);
        data.sb.append("\n");
        data.sb.append(Main.cookies);
        data.sb.append("\n");
        data.sb.append(Main.cps);
        data.sb.append("\n");
        data.sb.append(Main.cpc);
        data.sb.append("\n");
        data.sb.append(Main.CookieUpgradeCost);
        data.sb.append("\n");
        
        for(int i = 0; i<Gui.upgrade.length; i++){
            data.sb.append(Gui.upgrade[i].getAnzahl());
            data.sb.append("\n");
            data.sb.append(Gui.upgrade[i].getCost());
            data.sb.append("\n");
        }
        
        data.sb.append(Main.StatsClickCount);
        data.sb.append("\n");
        data.sb.append(Main.StatsCookiesTotal);
        data.sb.append("\n");
        
        for(int i = 0; i<Main.achievementAnzahl; i++){
            if(Gui.achievement[i].isUnlocked()){
                data.sb.append("1");
                data.sb.append("\n");
            }else{
                data.sb.append("0");
                data.sb.append("\n");
            }
        }
        
        try {
            OutputStream stream = new FileOutputStream(data.file);
            String s = data.sb.toString();
            
            stream.write(s.getBytes());
            stream.flush();
            stream.close();
            
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        }

    }
    
    public static void loadData(){
        
        JFileChooser chooser = new JFileChooser();
        
        int temp = chooser.showOpenDialog(null);
        if(temp == JFileChooser.APPROVE_OPTION){
            String s = chooser.getSelectedFile().getAbsolutePath();
            if(s.endsWith("save.txt")){
                
                File file = new File(s);
                try {
                    Scanner sc = new Scanner(file);
                    
                    Main.spielername = sc.nextLine();
                    Main.cookies = Double.parseDouble(sc.nextLine());
                    Main.cps = Double.parseDouble(sc.nextLine());
                    Main.cpc = Double.parseDouble(sc.nextLine());
                    Main.CookieUpgradeCost = Double.parseDouble(sc.nextLine());
                    
                    for(int i = 0; i<Gui.upgrade.length; i++){
                        Gui.upgrade[i].setAnzahl(Integer.parseInt(sc.nextLine()));
                        Gui.upgrade[i].setCost(Double.parseDouble(sc.nextLine()));
                    }
                    
                    Main.StatsClickCount = Integer.parseInt(sc.nextLine());
                    Main.StatsCookiesTotal = Double.parseDouble(sc.nextLine());
                    
                    for(int i = 0; i<Main.achievementAnzahl; i++){
                        if(sc.nextLine().equals("1")){
                            Gui.achievement[i].setUnlocked(true);
                        }else{
                            Gui.achievement[i].setUnlocked(false);
                        }
                    }
                    
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else{
                System.out.println("Fehler beim Einlesen");
            }
        }
        
    }
    
    
    public static void loadStart(){
   
                File save = new File("saves/"+Main.spielername+"save.txt");
                
                if (!save.exists()) {
			try {
				save.createNewFile();
                                
                }   catch (IOException ex) {
                        Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
                    }
                        
		}else{
                    
                try {
                    Scanner sc = new Scanner(save);
                    
                    if(sc.hasNextLine()){
                    Main.spielername = sc.nextLine();
                    Main.cookies = Double.parseDouble(sc.nextLine());
                    Main.cps = Double.parseDouble(sc.nextLine());
                    Main.cpc = Double.parseDouble(sc.nextLine());
                    Main.CookieUpgradeCost = Double.parseDouble(sc.nextLine());
                    
                    for(int i = 0; i<Gui.upgrade.length; i++){
                        Gui.upgrade[i].setAnzahl(Integer.parseInt(sc.nextLine()));
                        Gui.upgrade[i].setCost(Double.parseDouble(sc.nextLine()));
                    }
                    
                    Main.StatsClickCount = Integer.parseInt(sc.nextLine());
                    Main.StatsCookiesTotal = Double.parseDouble(sc.nextLine());
                    
                    for(int i = 0; i<Main.achievementAnzahl; i++){
                        if(sc.nextLine().equals("1")){
                            Gui.achievement[i].setUnlocked(true);
                        }else{
                            Gui.achievement[i].setUnlocked(false);
                        }
                    }
                    }
                    
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    }
    
    public static void setAchievementText(){
        File achText = new File("data/achtext.txt");
        if(achText!=null){
            try {
                Scanner sc = new Scanner(achText);
                for(int i = 0; i<Main.achievementAnzahl; i++){
                    Gui.achievement[i].setText(sc.nextLine());
                }
                
                        } catch (FileNotFoundException ex) {
                System.out.println("Achievement Texte konnten nicht eingelesen werden.");
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public static void setAchievementName(){
        File achName = new File("data/achname.txt");
        if(achName!=null){
            try {
                Scanner sc = new Scanner(achName);
                for(int i = 0; i<Main.achievementAnzahl; i++){
                    Gui.achievement[i].setName(sc.nextLine());
                }
                
                        } catch (FileNotFoundException ex) {
                System.out.println("Achievement Namen konnten nicht eingelesen werden.");
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
        
 
    
    
}


