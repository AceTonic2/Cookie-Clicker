
package Actions;

import GUI.Gui;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Highscore {
    
    static File folder = new File("saves");
    static File[] listOfFiles = folder.listFiles();
    
    public static double bestCookies[] = new double[listOfFiles.length];
    public static String bestCookiesName[] = new String[listOfFiles.length];
    public static double bestClicks[] = new double[listOfFiles.length];
    public static String bestClicksName[] = new String[listOfFiles.length];
    public static double bestCpc[] = new double[listOfFiles.length];
    public static String bestCpcName[] = new String[listOfFiles.length];
    public static double bestCps[] = new double[listOfFiles.length];
    public static String bestCpsName[] = new String[listOfFiles.length];
    
    String spielername = null;
    double cookies, cps, cpc, CookieUpgradeCost;
    double upgradeCost[] = new double[Main.upgradeAnzahl];
    int upgradeAnzahl[] = new int[Main.upgradeAnzahl];
    int StatsClickCount;
    double StatsCookiesTotal;
    Timer timer;
    
    int vorhanden = 0;
    
public Highscore() {
    timer = new Timer();
    
    timer.scheduleAtFixedRate(new TimerTask() {
        @Override
        public void run() {
            
        for(int i = 0; i<listOfFiles.length; i++){
        File file = listOfFiles[i];
        
        if(file.getName().endsWith("save.txt")){
           if(file.getName()!=null){
               
            
            try {
                    Scanner sc = new Scanner(file);
                    
                    if(sc.hasNextLine()){
                    spielername = sc.nextLine();
                    cookies = Double.parseDouble(sc.nextLine());
                    cps = Double.parseDouble(sc.nextLine());
                    cpc = Double.parseDouble(sc.nextLine());
                    CookieUpgradeCost = Double.parseDouble(sc.nextLine());
                    
                    for(int ii = 0; ii<Gui.upgrade.length; ii++){
                        upgradeAnzahl[ii] = Integer.parseInt(sc.nextLine());
                        upgradeCost[ii] = Double.parseDouble(sc.nextLine());
                    }
                    
                    StatsClickCount = Integer.parseInt(sc.nextLine());
                    StatsCookiesTotal = Double.parseDouble(sc.nextLine());
                    
                    for(int ii = 0; ii<Main.achievementAnzahl; ii++){
                        if(sc.nextLine().equals("1")){
                            //Gui.achievement[ii].setUnlocked(true); UNWICHTIG
                        }else{
                            //Gui.achievement[ii].setUnlocked(false); UNWICHTIG
                        }
                    }
                    }
                    
                    if(spielername!=null){
                    vorhanden=0;
                    for(int iii = 0; iii<bestCookies.length; iii++){
                        if(spielername.equals(bestCookiesName[iii]) && vorhanden == 0){
                            vorhanden++;
                            if(cookies > bestCookies[iii]){
                            bestCookies[iii] = cookies;
                            }
                            if(cookies < bestCookies[iii]){
                            bestCookies[iii] = 0;
                            bestCookiesName[iii] = null;
                            }
                        }else{
                        if(cookies > bestCookies[iii] && vorhanden == 0){
                            vorhanden++;
                            bestCookies[iii] = cookies;
                            bestCookiesName[iii] = spielername;
                            }else if(spielername.equals(bestCookiesName[iii]) && vorhanden > 0){
                            bestCookies[iii] = 0;
                        }
                        if(bestCookiesName[iii]==null){
                            bestCookiesName[iii] = "unbelegt";
                            bestCookies[iii] = -1337;
                        }
                        }

                    }
                    
                    vorhanden=0;
                    for(int iii = 0; iii<bestClicks.length; iii++){
                        if(spielername.equals(bestClicksName[iii]) && vorhanden == 0){
                            vorhanden++;
                            if(StatsClickCount > bestClicks[iii]){
                            bestClicks[iii] = StatsClickCount;
                            }
                            if(StatsClickCount < bestClicks[iii]){
                            bestClicks[iii] = 0;
                            bestClicksName[iii] = null;
                            }
                        }else{
                        if(StatsClickCount > bestClicks[iii] && vorhanden == 0){
                            vorhanden++;
                            bestClicks[iii] = StatsClickCount;
                            bestClicksName[iii] = spielername;
                            }else if(spielername.equals(bestClicksName[iii]) && vorhanden > 0){
                            bestClicks[iii] = 0;
                        }
                        if(bestClicksName[iii]==null){
                            bestClicksName[iii] = "unbelegt";
                            bestClicks[iii] = -1337;
                        }
                        }

                    }
                    
                    vorhanden=0;
                    for(int iii = 0; iii<bestCpc.length; iii++){
                        if(spielername.equals(bestCpcName[iii]) && vorhanden == 0){
                            vorhanden++;
                            if(cpc > bestCpc[iii]){
                            bestCpc[iii] = cpc;
                            }
                            if(cpc < bestCpc[iii]){
                            bestCpc[iii] = 0;
                            bestCpcName[iii] = null;
                            }
                        }else{
                        if(cpc > bestCpc[iii] && vorhanden == 0){
                            bestCpc[iii] = cpc;
                            bestCpcName[iii] = spielername;
                            }
                        if(spielername.equals(bestCpcName[iii]) && vorhanden > 0){
                            bestCpc[iii] = 0;
                        }
                        }

                    }
                    
                    vorhanden=0;
                    for(int iii = 0; iii<bestCps.length; iii++){
                        if(spielername.equals(bestCpsName[iii]) && vorhanden == 0){
                            vorhanden++;
                            if(cps > bestCps[iii]){
                            bestCps[iii] = cps;
                            }
                            if(cps < bestCps[iii]){
                            bestCps[iii] = 0;
                            bestCpsName[iii] = null;
                            }
                        }else{
                        if(cps > bestCps[iii] && vorhanden == 0){
                            vorhanden++;
                            bestCps[iii] = cps;
                            bestCpsName[iii] = spielername;
                            }else if(spielername.equals(bestCpsName[iii]) && vorhanden > 0){
                            bestCps[iii] = 0;
                        }
                        if(bestCpsName[iii]==null){
                            bestCpsName[iii] = "unbelegt";
                            bestCps[iii] = -1337;
                        }
                        }

                    }
                    
                    } 
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
                }
            
           }
        }
    }
    
        //Ausgabe zum Test
    /*for(int i =0; i<bestCookies.length; i++){
        System.out.print("Name: "+bestCookiesName[i]);
        System.out.println("       Cookies: "+bestCookies[i]);
    }
            System.out.println("");
          */  
        }
    }, 0, 1);
    
}
}
