
package GUI;

import Actions.Main;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class IL {
    
   public BufferedImage ibg; //imagebackground
   public BufferedImage iupgrade[] = new BufferedImage[Main.upgradeAnzahl]; //upgrade Bilder
   public BufferedImage icookie1, icookie2; // 1 = normaler Cookie, 2 = kleinerer Cookie
   public BufferedImage iachievement[] = new BufferedImage[Main.achievementAnzahl];
   
   public IL(){
       
       try {
           ibg = ImageIO.read(new File("rsc/bg.png"));
           icookie1 = ImageIO.read(new File("rsc/cookie1.png"));
           icookie2 = ImageIO.read(new File("rsc/cookie2.png"));
           
           for(int i = 0; i<iupgrade.length; i++){
               iupgrade[i] = ImageIO.read(new File("rsc/upgrade" + (i+1) + ".png"));
           }
           
           for(int i = 0; i < iachievement.length; i++){
               iachievement[i] = ImageIO.read(new File("rsc/achievements/ach" + (i+1) + ".png"));
           }
           
       } catch (IOException e) {
           e.printStackTrace();
       }
       
   }
   
}
