
package GUI;

import Actions.Main;
import java.awt.image.BufferedImage;

public class Upgrade {
  
    Gui gui = new Gui();
    
    public int x, y;
    public int width = gui.width/3;
    public int height = 150;
    public String name;
    public BufferedImage image;
    public int anzahl;
    public double cost;
    
    public Upgrade(String name, BufferedImage image, int cost){
        this.x = gui.width/3;
        this.name = name;
        this.image = image;
        this.anzahl = 0;
        this.cost = cost;
        
    }
    
    public static int setYCoord(int index){
        return 150 + index*200;
    }
    
    public static void cpsUpgrade(int index){
        switch(index){
            case 0:
                Main.cps+=0.1;
                break;
            case 1:
                Main.cps += 1;
                break;
            case 2:
                Main.cps += 10;
                break;
            case 3:
                Main.cps += 100;
                break;
            case 4:
                Main.cps += 1000;
                break;
        }
        
        
    }

    public Gui getGui() {
        return gui;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public String getName() {
        return name;
    }

    public BufferedImage getImage() {
        return image;
    }

    public int getAnzahl() {
        return anzahl;
    }

    public double getCost() {
        return cost;
    }

    public void setGui(Gui gui) {
        this.gui = gui;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setImage(BufferedImage image) {
        this.image = image;
    }

    public void setAnzahl(int anzahl) {
        this.anzahl = anzahl;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
    
    
    
}
