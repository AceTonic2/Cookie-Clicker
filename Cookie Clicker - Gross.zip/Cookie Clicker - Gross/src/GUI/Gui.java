
package GUI;

import Actions.Data;
import Actions.FocusHandler;
import Actions.Main;
import Actions.MouseHandler;
import Actions.SliderListener;
import Draw.Draw_Achievements;
import Draw.Draw_Main;
import Draw.Draw_Buttons;
import Draw.Draw_Highscore;
import Draw.Draw_Options;
import Draw.Draw_Start;
import Draw.Draw_Upgrades;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseWheelListener;
import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.JTextField;

public class Gui {

    JFrame jf;
    Draw_Main d;
    Draw_Buttons db;
    Draw_Upgrades du;
    Draw_Options dop;
    Draw_Start ds;
    Draw_Achievements da;
    Draw_Highscore dh;
    IL il = new IL();
    SliderListener sl = new SliderListener();
    
    public static JTextField jt = new JTextField("Name", 10);
    public static JSlider jsSound = new JSlider(JSlider.HORIZONTAL, 0, 100, Main.volumeSound);
    public static JSlider jsMusic = new JSlider(JSlider.HORIZONTAL, 0, 100, Main.volumeMusic);
    
    public final int width = 1920, height = 1080;
    
    public static int maxHeight, actualHeight = 0;
    
    public static Button buttonUpgrades, buttonAchievements, buttonOptions, buttonCookieUpgrade, buttonCookie, buttonSubmit, buttonHighscore;
    public static Button buttonHighscoreCookies, buttonHighscoreClicks, buttonHighscoreCpc, buttonHighscoreCps;
    public static Button buyUpgradeButton[] = new Button[Main.upgradeAnzahl];
    public static Upgrade upgrade[] = new Upgrade[Main.upgradeAnzahl];
    
    public static Achievement achievement[] = new Achievement[Main.achievementAnzahl];
    public static AchievementSlider achievementSlider[] = new AchievementSlider[Main.achievementAnzahl];
           
    public void createGui(){
        
        //neue buttons erstellen (x, y, width, height)
        buttonUpgrades = new Button(width/3, 0, 146+50, 100);
        buttonUpgrades.active = true;
        buttonAchievements = new Button(width/3 + 196, 0, 219+50, 100);
        buttonOptions = new Button(width/3 + 196 + 269 , 0, 175, 100);
        buttonHighscore = new Button(width/3 + 196 + 269 + 175, 0, 206, 100);
        
        buttonCookie = new Button((width/6)-(384/2), 300, 384, 384);
        buttonCookieUpgrade = new Button((width/6)-(200/2), 850, 200, 60);
        
        buttonSubmit = new Button(width/2 - 150/2, 565 , 150, 55);
        
        buttonHighscoreCookies = new Button(width/3 + 25, 125, 145, 55);
        buttonHighscoreCookies.active = true;
        buttonHighscoreClicks = new Button(width/3 + 50 + 145, 125, 118, 55);
        buttonHighscoreCpc = new Button(width/3 + 75 + 145 + 118, 125, 80, 55);
        buttonHighscoreCps = new Button(width/3 + 100 + 145 + 118 + 80, 125, 80, 55);
        
        //erstellt mehrere Upgrades
        for(int i = 0; i<upgrade.length; i++){
            buyUpgradeButton[i] = new Button();
            buyUpgradeButton[i].y = 150 + (i*200) + 85;
            buyUpgradeButton[i].x = (width/3) + (((width/3)/3)*2) + 20;
            buyUpgradeButton[i].width = 170;
            buyUpgradeButton[i].height = 40;
        }
        
        //Upgradefestlegung (name, bild, kosten)
        upgrade[0] = new Upgrade("Ofen", il.iupgrade[0], 10);
        upgrade[1] = new Upgrade("Azubi", il.iupgrade[1], 100);
        upgrade[2] = new Upgrade("Chefkoch", il.iupgrade[2], 1000);
        upgrade[3] = new Upgrade("Bagger", il.iupgrade[3], 10000);
        upgrade[4] = new Upgrade("Fabrik", il.iupgrade[4], 100000);
        
        for(int i = 0; i < upgrade.length; i++){
            upgrade[i].setY(Upgrade.setYCoord(i));
        }
        
        maxHeight = (upgrade.length * (150+50));
        
        int temp = 0;
        int yVerschiebung = 0;
        int xVerschiebung = 0;
        
        for(int i = 0; i < achievement.length; i++){
            achievement[i] = new Achievement(width/3 + 7 + xVerschiebung, 100 + 7 + yVerschiebung, il.iachievement[i]);
            
            temp++;
            
            if(temp%12 == 0){
                temp = 0;
                yVerschiebung += 52;
            }
            
            xVerschiebung = temp*50 + temp*2;
        }
        
        Data.setAchievementName();
        Data.setAchievementText();
        
        for(int i = 0; i<achievementSlider.length; i++){
            achievementSlider[i] = new AchievementSlider(achievement[i]);
        }
        
    
        jf = new JFrame("Cookie Clicker");
        jf.setSize(width, height);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setLocationRelativeTo(null);
        jf.addMouseWheelListener(new MouseHandler());
        jf.setResizable(false);
        
        jsSound.setBackground(new Color(0,0,0,0));
        jsSound.addFocusListener(new FocusHandler());
        jsSound.setVisible(false);
        jsSound.addChangeListener(sl);
        jf.add(jsSound);
        
        jsMusic.setBackground(new Color(0,0,0,0));
        jsMusic.addFocusListener(new FocusHandler());
        jsMusic.setVisible(false);
        jsMusic.addChangeListener(sl);
        jf.add(jsMusic);
        
        jt.setBounds(width/2 - 700/2, 440, 700, 90);
        jt.setBackground(new Color(0,0,0,0));
        jt.setForeground(Color.WHITE);
        jt.setFont(new Font("Arial",Font.BOLD, 50));
        jt.addFocusListener(new FocusHandler());
        jt.setVisible(true);
        jf.add(jt);
        
        ds = new Draw_Start();
        ds.setSize(width, height);
        ds.setVisible(true);
        ds.requestFocus();
        ds.addMouseListener(new MouseHandler());
        ds.addMouseMotionListener(new MouseHandler());
        jf.add(ds);
        
        db = new Draw_Buttons();
        db.setSize(width, height);
        db.setVisible(true);
        db.requestFocus();
        db.addMouseListener(new MouseHandler());
        db.addMouseMotionListener(new MouseHandler());
        jf.add(db);
        
        dh = new Draw_Highscore();
        dh.setSize(width, height);
        dh.setVisible(true);
        dh.requestFocus();
        dh.addMouseListener(new MouseHandler());
        dh.addMouseMotionListener(new MouseHandler());
        jf.add(dh);
        
        du = new Draw_Upgrades();
        du.setSize(width, height);
        du.setVisible(true);
        du.requestFocus();
        du.addMouseListener(new MouseHandler());
        du.addMouseMotionListener(new MouseHandler());
        jf.add(du);
        
        dop = new Draw_Options();
        dop.setSize(width, height);
        dop.setVisible(true);
        dop.requestFocus();
        dop.addMouseListener(new MouseHandler());
        dop.addMouseMotionListener(new MouseHandler());
        jf.add(dop);
        
        da = new Draw_Achievements();
        da.setSize(width, height);
        da.setVisible(true);
        da.requestFocus();
        da.addMouseListener(new MouseHandler());
        da.addMouseMotionListener(new MouseHandler());
        jf.add(da);
        
        d = new Draw_Main();
        d.setSize(width, height);
        d.setVisible(true);
        d.requestFocus();
        d.addMouseListener(new MouseHandler());
        d.addMouseMotionListener(new MouseHandler());
        jf.add(d);
        
        jf.setVisible(true);
        
        jf.requestFocusInWindow();
        
        
    }
    
}
