

package Draw;

import GUI.Gui;
import GUI.IL;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JLabel;

public class Draw_Buttons extends JLabel{
    
    Gui gui = new Gui();
    IL il = new IL();
    int textWidth;
    
protected void paintComponent(Graphics g){
    
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    
        //Buttons Menuleiste
        g.setFont(new Font("Arial",Font.BOLD, 32));
        
        //Button Upgrades
        if(Gui.buttonUpgrades.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(Gui.buttonUpgrades.getX(), Gui.buttonUpgrades.getY(), Gui.buttonUpgrades.getWidth(), Gui.buttonUpgrades.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        if(Gui.buttonUpgrades.isActive()){
            g.setColor(new Color(22, 135, 128));
            g.fillRect(Gui.buttonUpgrades.getX(), Gui.buttonUpgrades.getY(), Gui.buttonUpgrades.getWidth(), Gui.buttonUpgrades.getHeight());
        }
        
        g.setColor(Color.WHITE);
        g.drawString("Upgrades", gui.width/3+25, 60);
        
        
        
        //Button Achievements
        if(Gui.buttonAchievements.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(Gui.buttonAchievements.getX(), Gui.buttonAchievements.getY(), Gui.buttonAchievements.getWidth(), Gui.buttonAchievements.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        if(Gui.buttonAchievements.isActive()){
            g.setColor(new Color(22, 135, 128));
            g.fillRect(Gui.buttonAchievements.getX(), Gui.buttonAchievements.getY(), Gui.buttonAchievements.getWidth(), Gui.buttonAchievements.getHeight());
        }
        
        g.setColor(Color.WHITE);
        //textWidth = g.getFontMetrics().stringWidth("Cpc");
        //System.out.println(textWidth);
        g.drawString("Achievements",gui.width/3 + 196 + 25, 60);
        
        
        
        //Button Options
        if(Gui.buttonOptions.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(Gui.buttonOptions.getX(), Gui.buttonOptions.getY(), Gui.buttonOptions.getWidth(), Gui.buttonOptions.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        if(Gui.buttonOptions.isActive()){
            g.setColor(new Color(22, 135, 128));
            g.fillRect(Gui.buttonOptions.getX(), Gui.buttonOptions.getY(), Gui.buttonOptions.getWidth(), Gui.buttonOptions.getHeight());
        }
        
        g.setColor(Color.WHITE);
        //textWidth = g.getFontMetrics().stringWidth("Options");
        g.drawString("Options", gui.width/3 + 196 + 269 + 25, 60);
        
        //Button Highscore
        if(Gui.buttonHighscore.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(Gui.buttonHighscore.getX(), Gui.buttonHighscore.getY(), Gui.buttonHighscore.getWidth(), Gui.buttonHighscore.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        if(Gui.buttonHighscore.isActive()){
            g.setColor(new Color(22, 135, 128));
            g.fillRect(Gui.buttonHighscore.getX(), Gui.buttonHighscore.getY(), Gui.buttonHighscore.getWidth(), Gui.buttonHighscore.getHeight());
        }
        
        g.setColor(Color.WHITE);
        g.drawString("Highscore", gui.width/3+196 + 269 + 175 + 25, 60);
        
        //Cookie Button
        if(Gui.buttonCookie.isActive()){
            g.drawImage(il.icookie2, Gui.buttonCookie.getX() + (60/4), Gui.buttonCookie.getY() + (60/4), Gui.buttonCookie.getWidth() - (60/2), Gui.buttonCookie.getHeight() - (60/2), null); //60Pixel kleiner als der größerer
        }else{
            g.drawImage(il.icookie1, Gui.buttonCookie.getX(), Gui.buttonCookie.getY(), Gui.buttonCookie.getWidth(), Gui.buttonCookie.getHeight(), null);
        }
        
        repaint();
        }
}
