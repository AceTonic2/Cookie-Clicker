
package Draw;

import Actions.Highscore;
import GUI.Gui;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JLabel;

public class Draw_Highscore extends JLabel{
    
    Gui gui = new Gui();
    int textWidth;
    
    protected void paintComponent(Graphics g){
        
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        if(Gui.buttonHighscore.isActive()){
 
        //Button Cookies
        if(Gui.buttonHighscoreCookies.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(Gui.buttonHighscoreCookies.getX(), Gui.buttonHighscoreCookies.getY(), Gui.buttonHighscoreCookies.getWidth(), Gui.buttonHighscoreCookies.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        if(Gui.buttonHighscoreCookies.isActive()){
            g.setColor(new Color(22, 135, 128));
            g.fillRect(Gui.buttonHighscoreCookies.getX(), Gui.buttonHighscoreCookies.getY(), Gui.buttonHighscoreCookies.getWidth(), Gui.buttonHighscoreCookies.getHeight());
        }
        
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial",Font.BOLD, 32));
        g.drawRect(Gui.buttonHighscoreCookies.getX(), Gui.buttonHighscoreCookies.getY(), Gui.buttonHighscoreCookies.getWidth(), Gui.buttonHighscoreCookies.getHeight());
        g.drawString("Cookies",Gui.buttonHighscoreCookies.getX() + 10 , Gui.buttonHighscoreCookies.getY() + 40 );
        
        
        //Button Clicks
        if(Gui.buttonHighscoreClicks.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(Gui.buttonHighscoreClicks.getX(), Gui.buttonHighscoreClicks.getY(), Gui.buttonHighscoreClicks.getWidth(), Gui.buttonHighscoreClicks.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        if(Gui.buttonHighscoreClicks.isActive()){
            g.setColor(new Color(22, 135, 128));
            g.fillRect(Gui.buttonHighscoreClicks.getX(), Gui.buttonHighscoreClicks.getY(), Gui.buttonHighscoreClicks.getWidth(), Gui.buttonHighscoreClicks.getHeight());
        }
        
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial",Font.BOLD, 32));
        g.drawRect(Gui.buttonHighscoreClicks.getX(), Gui.buttonHighscoreClicks.getY(), Gui.buttonHighscoreClicks.getWidth(), Gui.buttonHighscoreClicks.getHeight());
        g.drawString("Clicks",Gui.buttonHighscoreClicks.getX() + 10 , Gui.buttonHighscoreClicks.getY() + 40 );
        
        
        //Button Cpc
        if(Gui.buttonHighscoreCpc.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(Gui.buttonHighscoreCpc.getX(), Gui.buttonHighscoreCpc.getY(), Gui.buttonHighscoreCpc.getWidth(), Gui.buttonHighscoreCpc.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        if(Gui.buttonHighscoreCpc.isActive()){
            g.setColor(new Color(22, 135, 128));
            g.fillRect(Gui.buttonHighscoreCpc.getX(), Gui.buttonHighscoreCpc.getY(), Gui.buttonHighscoreCpc.getWidth(), Gui.buttonHighscoreCpc.getHeight());
        }
        
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial",Font.BOLD, 32));
        g.drawRect(Gui.buttonHighscoreCpc.getX(), Gui.buttonHighscoreCpc.getY(), Gui.buttonHighscoreCpc.getWidth(), Gui.buttonHighscoreCpc.getHeight());
        g.drawString("Cpc",Gui.buttonHighscoreCpc.getX() + 10 , Gui.buttonHighscoreCpc.getY() + 40 );
        
        
        //Button Cps
        if(Gui.buttonHighscoreCps.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(Gui.buttonHighscoreCps.getX(), Gui.buttonHighscoreCps.getY(), Gui.buttonHighscoreCps.getWidth(), Gui.buttonHighscoreCps.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        if(Gui.buttonHighscoreCps.isActive()){
            g.setColor(new Color(22, 135, 128));
            g.fillRect(Gui.buttonHighscoreCps.getX(), Gui.buttonHighscoreCps.getY(), Gui.buttonHighscoreCps.getWidth(), Gui.buttonHighscoreCps.getHeight());
        }
        
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial",Font.BOLD, 32));
        g.drawRect(Gui.buttonHighscoreCps.getX(), Gui.buttonHighscoreCps.getY(), Gui.buttonHighscoreCps.getWidth(), Gui.buttonHighscoreCps.getHeight());
        g.drawString("Cps",Gui.buttonHighscoreCps.getX() + 10 , Gui.buttonHighscoreCps.getY() + 40 );
        
        
        if(Gui.buttonHighscoreCookies.isActive()){
            
            for(int i = 0, yVerschiebung = 0; i<Highscore.bestCookies.length; i++){
                
                yVerschiebung = i*50;
                
                g.setFont(new Font("Arial",Font.BOLD, 26));
                g.setColor(Color.WHITE);
                g.drawRect(gui.width/3 + 25, 150 + yVerschiebung + 40 + 10, gui.width/3*2 - 50, 40);
                g.drawString(Highscore.bestCookiesName[i], gui.width/3 + 25+10, 150 + yVerschiebung + 40 + 10 + 30);
                String s = (Integer.toString((int)Highscore.bestCookies[i]));
                textWidth = g.getFontMetrics().stringWidth(s+ " Cookies");
                g.drawString(s + " Cookies", gui.width - 25 - textWidth, 150 + yVerschiebung + 40 + 10 + 30);
                
            }
        }
        
        if(Gui.buttonHighscoreClicks.isActive()){
            
            for(int i = 0, yVerschiebung = 0; i<Highscore.bestClicks.length; i++){
                
                yVerschiebung = i*50;
                
                g.setFont(new Font("Arial",Font.BOLD, 26));
                g.setColor(Color.WHITE);
                g.drawRect(gui.width/3 + 25, 150 + yVerschiebung + 40 + 10, gui.width/3*2 - 50, 40);
                g.drawString(Highscore.bestClicksName[i], gui.width/3 + 25+10, 150 + yVerschiebung + 40 + 10 + 30);
                String s = (Integer.toString((int)Highscore.bestClicks[i]));
                textWidth = g.getFontMetrics().stringWidth(s+ " Clicks");
                g.drawString(s + " Clicks", gui.width - 25 - textWidth, 150 + yVerschiebung + 40 + 10 + 30);
                
            }
        }
        
        if(Gui.buttonHighscoreCpc.isActive()){
            
            for(int i = 0, yVerschiebung = 0; i<Highscore.bestCpc.length; i++){
                
                yVerschiebung = i*50;
                
                g.setFont(new Font("Arial",Font.BOLD, 26));
                g.setColor(Color.WHITE);
                g.drawRect(gui.width/3 + 25, 150 + yVerschiebung + 40 + 10, gui.width/3*2 - 50, 40);
                g.drawString(Highscore.bestCpcName[i], gui.width/3 + 25+10, 150 + yVerschiebung + 40 + 10 + 30);
                String s = (Integer.toString((int)Highscore.bestCpc[i]));
                textWidth = g.getFontMetrics().stringWidth(s+ " Cpc");
                g.drawString(s + " Cpc", gui.width - 25 - textWidth, 150 + yVerschiebung + 40 + 10 + 30);
                
            }
        }
        
        if(Gui.buttonHighscoreCps.isActive()){
            
            for(int i = 0, yVerschiebung = 0; i<Highscore.bestCps.length; i++){
                
                yVerschiebung = i*50;
                
                g.setFont(new Font("Arial",Font.BOLD, 26));
                g.setColor(Color.WHITE);
                g.drawRect(gui.width/3 + 25, 150 + yVerschiebung + 40 + 10, gui.width/3*2 - 50, 40);
                g.drawString(Highscore.bestCpsName[i], gui.width/3 + 25+10, 150 + yVerschiebung + 40 + 10 + 30);
                String s = (Integer.toString((int)Highscore.bestCps[i]));
                textWidth = g.getFontMetrics().stringWidth(s+ " Cps");
                g.drawString(s + " Cps", gui.width - 25 - textWidth, 150 + yVerschiebung + 40 + 10 + 30);
                
            }
        }
        
        
        }
        
        repaint();
    }
}
