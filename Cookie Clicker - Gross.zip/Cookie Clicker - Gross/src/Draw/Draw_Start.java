
package Draw;

import Actions.Audio;
import Actions.Data;
import Actions.Highscore;
import Actions.Main;
import GUI.Button;
import GUI.Gui;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JLabel;

public class Draw_Start extends JLabel {
    
    Gui gui = new Gui();
    int textWidth, hilf = 200;
    public static boolean submitPressed = false;
    boolean once = true;
    
    protected void paintComponent(Graphics g){
        
        if(Main.start){
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        //Transparenz wird immer geringer und bei 0 wird Start beendet
        if(submitPressed){
            if(hilf>0){
                hilf--;
            }else{
                submitPressed=false;
                Main.start=false;
            }
        }
        
        //Damit es smooth ausfaded
        try {
        Thread.sleep(1); //normal: 7
    } catch (InterruptedException e) {

        e.printStackTrace();
    }
        
        g.setColor(new Color(0,0,0,hilf));
        g.fillRect(0, 0, gui.width, gui.height);
        
        if(!submitPressed){
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 40));
        textWidth = g.getFontMetrics().stringWidth("Bitte geben Sie einen Namen ein!");
        g.drawString("Bitte geben Sie einen Namen ein!", (gui.width/2) - (textWidth/2), 413);
        
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 40));
        textWidth = g.getFontMetrics().stringWidth("Submit");
        g.drawString("Submit", (gui.width/2) - (textWidth/2), 605);
        
        g.setColor(Color.WHITE);
        g.drawRect(Gui.buttonSubmit.getX(), Gui.buttonSubmit.getY(), Gui.buttonSubmit.getWidth(), Gui.buttonSubmit.getHeight());
        
        }else{
            if (once){ //sonst wiederholt er das immer wieder und der name wird zu bsp. "Acetonic, name, name, name, name" gesetzt
            Gui.jt.setVisible(false);
            Main.spielername = Gui.jt.getText();
            once = false;
            Data.loadStart();
            //Audio.Music("data/audio/Music.wav"); nicht mit hochgeladen, da zu groß und unwichtig
            new Highscore();
            }
        }
        
        repaint();
        }
    }
    
}
