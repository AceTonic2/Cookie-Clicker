
package Draw;

import Actions.Main;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JLabel;

import GUI.Gui;
import java.awt.Color;
import java.awt.Font;

public class Draw_Options extends JLabel{
    
    Gui gui = new Gui();
    int textWidth;
    
     protected void paintComponent(Graphics g){
        
        
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        if(Gui.buttonOptions.isActive()){
            
            Gui.jsSound.setVisible(true);
            Gui.jsMusic.setVisible(true);
            
            //Soundeffekte
            //Background
            g.setColor(new Color(43,61,79,150));
            g.fillRect(gui.width/3 + 1, 150, gui.width, 150);
            
            //Umrandung
            g.setColor(new Color(255,255,255,150));
            g.drawLine(gui.width/3+1, 150, gui.width, 150);
            g.drawLine(gui.width/3+1, 150+150, gui.width, 150+150);
            
            //Soundeffektebutton
            g.drawRect(gui.width/3+25, 200, 200, 50);
            
            //Schrift
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 25));
            textWidth = g.getFontMetrics().stringWidth("Soundeffekte");
            g.drawString("Soundeffekte", (gui.width/3 + 125) - (textWidth/2), 233);
            
            //Slider
            Gui.jsSound.setBounds(gui.width/3+250, 220, 780, 15);
            
            //Sound value Kasten
            g.drawRect(gui.width-25-200, 200, 200, 50);
            
            //Sound value
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 25));
            textWidth = g.getFontMetrics().stringWidth(Integer.toString(Main.volumeSound));
            g.drawString(Integer.toString(Main.volumeSound), (gui.width-25-100) - (textWidth/2), 233);
            
            
            //Musik
            //Background
            g.setColor(new Color(43,61,79,150));
            g.fillRect(gui.width/3 + 1, 350, gui.width, 150);
            
            //Umrandung
            g.setColor(new Color(255,255,255,150));
            g.drawLine(gui.width/3+1, 350, gui.width, 350);
            g.drawLine(gui.width/3+1, 350+150, gui.width, 350+150);
            
            //Musikbutton
            g.drawRect(gui.width/3+25, 400, 200, 50);
            
            //Schrift
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 25));
            textWidth = g.getFontMetrics().stringWidth("Musik");
            g.drawString("Musik", (gui.width/3 + 125) - (textWidth/2), 233 + 200);
            
            //Slider
            Gui.jsMusic.setBounds(gui.width/3+250, 420, 780, 15);
            
            //Sound value Kasten
            g.drawRect(gui.width-25-200, 400, 200, 50);
            
            //Sound value
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 25));
            textWidth = g.getFontMetrics().stringWidth(Integer.toString(Main.volumeMusic));
            g.drawString(Integer.toString(Main.volumeMusic), (gui.width-25-100) - (textWidth/2), 433);
            
        }else{
            Gui.jsSound.setVisible(false);
            Gui.jsMusic.setVisible(false);
        }
}
     
}
