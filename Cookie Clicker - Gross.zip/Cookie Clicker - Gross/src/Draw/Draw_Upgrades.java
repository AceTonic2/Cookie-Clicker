
package Draw;

import Actions.Main;
import GUI.Gui;
import GUI.IL;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.text.DecimalFormat;
import javax.swing.JLabel;

public class Draw_Upgrades extends JLabel{
    
    Gui gui = new Gui();
    int textWidth;
    IL il = new IL();
    DecimalFormat df = new DecimalFormat("###,###,###");
    DecimalFormat df2 = new DecimalFormat("###,###,###.##");
    
protected void paintComponent(Graphics g){
    
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
   
        if(Gui.buttonUpgrades.isActive()){
            
            for(int i = 0; i<Gui.upgrade.length; i++){
                
                if(Gui.upgrade[i].getY() > 100){
                
                //Upgradebereich
                g.setColor(new Color(43,61,79,150));
                g.fillRect(Gui.upgrade[i].getX() + 1, Gui.upgrade[i].getY(), Gui.upgrade[i].getWidth(), Gui.upgrade[i].getHeight());
                
                //Umrahmung der Upgrades
                g.setColor(new Color(255,255,255,150));
                g.drawLine((gui.width/3)+1, Gui.upgrade[i].getY(), gui.width/3*2, Gui.upgrade[i].getY());
                g.drawLine((gui.width/3)+1, Gui.upgrade[i].getY() + 150, gui.width/3*2, Gui.upgrade[i].getY() + 150);
                
                //Trennlinien
                g.drawLine((gui.width/3) + ((gui.width/3)/3), gui.upgrade[i].getY(), (gui.width/3) + ((gui.width/3)/3), gui.upgrade[i].getY() + 150);
                g.drawLine((gui.width/3) + (((gui.width/3)/3) * 2), gui.upgrade[i].getY(), (gui.width/3) + (((gui.width/3)/3)*2), gui.upgrade[i].getY() + 150);
                
                g.drawLine(gui.width/3*2, 100, gui.width/3*2, gui.height);
                
                g.setColor(Color.WHITE);
                
                //Anzahl
                g.setFont(new Font("Arial", Font.PLAIN,28));
                textWidth = g.getFontMetrics().stringWidth(Integer.toString(Gui.upgrade[i].getAnzahl()));
                g.drawString(Integer.toString(Gui.upgrade[i].getAnzahl()), (gui.width/3) + (((gui.width/3)/3)/2) - (textWidth/2), Gui.upgrade[i].getY() + 60);
                
                //Name
                g.setFont(new Font("Arial", Font.PLAIN, 25));
                textWidth = g.getFontMetrics().stringWidth(Gui.upgrade[i].getName());
                g.drawString(Gui.upgrade[i].getName(), (gui.width/3) + (((gui.width/3)/3)/2) - (textWidth/2), Gui.upgrade[i].getY() + 110);
                
                //Bild
                g.drawImage(Gui.upgrade[i].getImage(), (gui.width/3) + ((gui.width/3)/3), Gui.upgrade[i].getY(), null);
                
                //Kosten
                String s = df.format(Gui.upgrade[i].getCost());
                textWidth = g.getFontMetrics().stringWidth(s + " Cookies");
                g.drawString(s + " Cookies", (int)((gui.width/3) + ((gui.width/3) * (5.0/6.0)) - textWidth/2), Gui.upgrade[i].getY() + 55);
                
                //buyUpgrades Buttons
                g.setColor(new Color(255,255,255,75));
                g.drawRect(Gui.buyUpgradeButton[i].getX(), Gui.buyUpgradeButton[i].getY(), Gui.buyUpgradeButton[i].getWidth(), Gui.buyUpgradeButton[i].getHeight());
                
                if(Gui.buyUpgradeButton[i].isHover()){
                    g.setColor(new Color(84,84,84,150));
                    g.fillRect(Gui.buyUpgradeButton[i].getX(), Gui.buyUpgradeButton[i].getY(), Gui.buyUpgradeButton[i].getWidth(), Gui.buyUpgradeButton[i].getHeight());
                }
                
                g.setColor(Color.WHITE);
                textWidth = g.getFontMetrics().stringWidth("Kaufen");
                g.drawString("Kaufen", (int)((gui.width/3) + ((gui.width/3) * (5.0/6.0)) - textWidth/2), Gui.upgrade[i].getY() + 113);
               
                }
            }
        }
        
        //Clicker Upgrade
        g.setFont(new Font("Arial", Font.PLAIN, 25));
        g.setColor(new Color(255,255,255,75));
        g.drawRect(gui.buttonCookieUpgrade.getX(), gui.buttonCookieUpgrade.getY(), gui.buttonCookieUpgrade.getWidth(), gui.buttonCookieUpgrade.getHeight());
        
        if(Gui.buttonCookieUpgrade.isHover()){
            g.setColor(new Color(84,84,84,150));
            g.fillRect(gui.buttonCookieUpgrade.getX(), gui.buttonCookieUpgrade.getY(), gui.buttonCookieUpgrade.getWidth(), gui.buttonCookieUpgrade.getHeight());
        }else{
            g.setColor(Color.WHITE);
        }
        
        g.setFont(new Font("Arial", Font.PLAIN, 45));
        g.setColor(Color.WHITE);
        textWidth = g.getFontMetrics().stringWidth("Upgrade");
        g.drawString("Upgrade", gui.width/6 - textWidth/2, 892);
        
        g.setFont(new Font("Arial", Font.PLAIN, 40));
        String s = df.format(Main.CookieUpgradeCost) + (" Cookies");
        textWidth = g.getFontMetrics().stringWidth(s);
        g.drawString(s, gui.width/6 - textWidth/2, 835);
        
        g.setFont(new Font("Arial", Font.PLAIN, 45));
        s = df2.format(Main.cpc) + " Cookies/klick";
        textWidth = g.getFontMetrics().stringWidth(s);
        g.drawString(s, gui.width/6 - textWidth/2, 955);
        
        repaint();
   }

}
